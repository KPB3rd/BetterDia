
// AintPaintDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AintPaint.h"
#include "AintPaintDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
	
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CAintPaintDlg dialog



CAintPaintDlg::CAintPaintDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CAintPaintDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAintPaintDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CANVAS, m_canvas);
	DDX_Control(pDX, IDC_MFCCOLORBUTTON3, m_wndLineColor);
	DDX_Control(pDX, IDC_MFCCOLORBUTTON2, m_wndFillColor);
	DDX_Control(pDX, IDC_COMBO1, m_wndThickness);
}

BEGIN_MESSAGE_MAP(CAintPaintDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &CAintPaintDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_CANVAS, &CAintPaintDlg::OnBnClickedCanvasgroup)
	ON_BN_CLICKED(IDOK, &CAintPaintDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON2, &CAintPaintDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON4, &CAintPaintDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON3, &CAintPaintDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON5, &CAintPaintDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &CAintPaintDlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_MFCCOLORBUTTON3, &CAintPaintDlg::OnBnClickedMfccolorbutton3)
	ON_BN_CLICKED(IDC_MFCCOLORBUTTON2, &CAintPaintDlg::OnBnClickedMfccolorbutton2)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CAintPaintDlg::OnCbnSelchangeCombo1)
	ON_BN_CLICKED(IDC_BUTTON7, &CAintPaintDlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON8, &CAintPaintDlg::OnBnClickedButton8)
END_MESSAGE_MAP()


// CAintPaintDlg message handlers

BOOL CAintPaintDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}


	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// Color Selector

	m_wndLineColor.EnableAutomaticButton(_T("Default"), afxGlobalData.clrBtnText);
	m_wndLineColor.EnableOtherButton(_T("Other..."));
	m_wndLineColor.SetColumnsNumber(3);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CAintPaintDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

void CAintPaintDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAintPaintDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


// Line Button
void CAintPaintDlg::OnBnClickedButton1()
{
	// TODO: Add your control notification handler code here
	m_canvas.SetTool(ToolButtonID(LINE));
}


void CAintPaintDlg::OnBnClickedCanvasgroup()
{
	// TODO: Add your control notification handler code here

}

void CAintPaintDlg::OnBnClickedOk()
{
	CDialogEx::OnOK();
}


// PolyLine Button
void CAintPaintDlg::OnBnClickedButton2()
{
	m_canvas.SetTool(ToolButtonID(POLYLINE));
}

// Square Button
void CAintPaintDlg::OnBnClickedButton3()
{
	m_canvas.SetTool(ToolButtonID(SQUARE));
}

// Cursor Button
void CAintPaintDlg::OnBnClickedButton4()
{
	m_canvas.SetTool(ToolButtonID(CURSOR));
}

// Bring to Front Button
void CAintPaintDlg::OnBnClickedButton5()
{
	m_canvas.BringtoFront();
}

// Rectangle Button
void CAintPaintDlg::OnBnClickedButton6()
{
	m_canvas.SetTool(ToolButtonID(RECT));
}

// Line Color Select
void CAintPaintDlg::OnBnClickedMfccolorbutton3()
{
	COLORREF lineColor = m_wndLineColor.GetColor();
	m_canvas.SetLineColor(lineColor);
	Invalidate();
}

// Fill Color Select
void CAintPaintDlg::OnBnClickedMfccolorbutton2()
{
	COLORREF fillColor = m_wndFillColor.GetColor();
	m_canvas.SetFillColor(fillColor);
	Invalidate();
}


// Thickness Combo Box
void CAintPaintDlg::OnCbnSelchangeCombo1()
{
	CString selection;
	// Gets selected value from combo box
	m_wndThickness.GetLBText(m_wndThickness.GetCurSel(), selection);

	// Converts string to int and sends to tools
	m_canvas.SetThickness(atoi((char*)(LPCTSTR)selection.GetString()));
	Invalidate();
}

// Save As... Button
void CAintPaintDlg::OnBnClickedButton7()
{
	m_canvas.SaveAs();
}


void CAintPaintDlg::OnBnClickedButton8()
{
	m_canvas.Load();
}
