
// AintPaintDlg.h : header file
//
#include "Canvas.h"

#pragma once


// CAintPaintDlg dialog
class CAintPaintDlg : public CDialogEx
{
// Construction
public:
	CAintPaintDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_AINTPAINT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

private: 
	Canvas m_canvas;
	CMFCColorButton	m_wndLineColor;
	CMFCColorButton	m_wndFillColor;
	CComboBox m_wndThickness;
	enum ToolButtonID { LINE, POLYLINE, SQUARE, RECT, CURSOR, NUM_TOOLS };
public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedCanvasgroup();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton6();
	afx_msg void OnBnClickedMfccolorbutton3();
	afx_msg void OnBnClickedMfccolorbutton2();
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnBnClickedButton7();
	afx_msg void OnBnClickedButton8();
};
